package com.fis.fisreservationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FisReservationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
