package com.fis.fisreservationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FisReservationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FisReservationServiceApplication.class, args);
	}

}
