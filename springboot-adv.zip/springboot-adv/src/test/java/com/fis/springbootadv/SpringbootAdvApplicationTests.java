package com.fis.springbootadv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootAdvApplicationTests {

	@Test
	void contextLoads() {
	}

}
