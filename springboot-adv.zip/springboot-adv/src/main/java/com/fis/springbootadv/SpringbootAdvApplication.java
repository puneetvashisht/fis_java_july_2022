package com.fis.springbootadv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootAdvApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootAdvApplication.class, args);
	}

}
