package com.fis.springbootjaxrsadv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootJaxrsAdvApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootJaxrsAdvApplication.class, args);
	}

}
