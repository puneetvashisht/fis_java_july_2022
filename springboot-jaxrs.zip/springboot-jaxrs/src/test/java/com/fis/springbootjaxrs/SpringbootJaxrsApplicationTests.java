package com.fis.springbootjaxrs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootJaxrsApplicationTests {

	@Test
	void contextLoads() {
	}

}
